const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const { createServer } = require('http');
const { Server } = require('socket.io');

const taskRoutes = require('./routes/tasks');
const userRoutes = require('./routes/users');

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: '*' } });

app.use(cors());
app.use(express.json());

// MongoDB connection
mongoose.connect('mongodb://127.0.0.1:27017/taskmanager', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error(err));

// Routes
app.use('/api/tasks', taskRoutes(io));
app.use('/api/users', userRoutes);

const PORT = 5000;
httpServer.listen(PORT, () => console.log('Server running on port', PORT));
