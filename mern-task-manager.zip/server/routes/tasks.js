const express = require('express');
const Task = require('../models/Task');

module.exports = function(io) {
  const router = express.Router();

  router.get('/', async (req, res) => {
    const tasks = await Task.find().populate('assignedTo');
    res.json(tasks);
  });

  router.post('/', async (req, res) => {
    const task = new Task(req.body);
    await task.save();
    io.emit('taskCreated', task);
    res.json(task);
  });

  router.put('/:id', async (req, res) => {
    const task = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true });
    io.emit('taskUpdated', task);
    res.json(task);
  });

  router.delete('/:id', async (req, res) => {
    await Task.findByIdAndDelete(req.params.id);
    io.emit('taskDeleted', req.params.id);
    res.json({ success: true });
  });

  return router;
}