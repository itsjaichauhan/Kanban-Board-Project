const mongoose = require('mongoose');
const User = require('./models/User');
const Task = require('./models/Task');

mongoose.connect('mongodb://127.0.0.1:27017/taskmanager')
  .then(async () => {
    await User.deleteMany({});
    await Task.deleteMany({});

    const users = await User.insertMany([
      { name: 'Alice', email: 'alice@example.com' },
      { name: 'Bob', email: 'bob@example.com' },
      { name: 'Charlie', email: 'charlie@example.com' }
    ]);

    await Task.insertMany([
      { title: 'Setup project', status: 'todo', assignedTo: users[0]._id },
      { title: 'Build frontend', status: 'inprogress', assignedTo: users[1]._id },
      { title: 'Write backend', status: 'done', assignedTo: users[2]._id }
    ]);

    console.log('Database seeded!');
    process.exit();
  });
