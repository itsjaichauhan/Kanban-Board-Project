import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { io } from 'socket.io-client';
import TaskBoard from './components/TaskBoard';

const socket = io('http://localhost:5000');

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [users, setUsers] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/tasks').then(res => setTasks(res.data));
    axios.get('http://localhost:5000/api/users').then(res => setUsers(res.data));

    socket.on('taskCreated', task => setTasks(prev => [...prev, task]));
    socket.on('taskUpdated', task => setTasks(prev => prev.map(t => t._id === task._id ? task : t)));
    socket.on('taskDeleted', id => setTasks(prev => prev.filter(t => t._id !== id)));

    return () => socket.off();
  }, []);

  return (
    <div style={{ padding: '20px' }}>
      <h1>Task Manager</h1>
      <TaskBoard tasks={tasks} users={users} />
    </div>
  );
}