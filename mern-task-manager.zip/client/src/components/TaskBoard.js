import React, { useState } from 'react';
import axios from 'axios';

export default function TaskBoard({ tasks, users }) {
  const [filter, setFilter] = useState('');
  const [search, setSearch] = useState('');

  const updateTask = async (id, updates) => {
    await axios.put('http://localhost:5000/api/tasks/' + id, updates);
  };

  const deleteTask = async (id) => {
    await axios.delete('http://localhost:5000/api/tasks/' + id);
  };

  const filteredTasks = tasks
    .filter(t => !filter || t.status === filter)
    .filter(t => t.title.toLowerCase().includes(search.toLowerCase()));

  return (
    <div>
      <div>
        <select onChange={e => setFilter(e.target.value)}>
          <option value=''>All</option>
          <option value='todo'>Todo</option>
          <option value='inprogress'>In Progress</option>
          <option value='done'>Done</option>
        </select>
        <input placeholder="Search..." onChange={e => setSearch(e.target.value)} />
      </div>
      <div style={{ display: 'flex', gap: '20px', marginTop: '20px' }}>
        {['todo', 'inprogress', 'done'].map(status => (
          <div key={status} style={{ flex: 1, border: '1px solid gray', padding: '10px' }}>
            <h3>{status.toUpperCase()}</h3>
            {filteredTasks.filter(t => t.status === status).map(task => (
              <div key={task._id} style={{ border: '1px solid black', margin: '5px', padding: '5px' }}>
                <p>{task.title}</p>
                <small>Assigned: {task.assignedTo?.name}</small><br/>
                <button onClick={() => updateTask(task._id, { status: status === 'todo' ? 'inprogress' : 'done' })}>
                  Move Next
                </button>
                <button onClick={() => deleteTask(task._id)}>Delete</button>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}